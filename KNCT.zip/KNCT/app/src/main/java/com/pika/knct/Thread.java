package com.pika.knct;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Thread extends AppCompatActivity {

    View view;
    RecyclerView recyclerView;
    List<AnswersCard> answersCardList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        answersCardList = new ArrayList<>();
        anwseradder();
        setContentView(R.layout.activity_thread);

        recyclerView = findViewById(R.id.answerRecycler);
        AnswersRecyclerViewAdapter answersRecyclerViewAdapter = new AnswersRecyclerViewAdapter(getApplicationContext(), answersCardList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(answersRecyclerViewAdapter);

    }

    public void anwseradder(){
        answersCardList.add(new AnswersCard(R.drawable.default_avatar,"Ramishncsncdskndskdnksndksnkdsdnsndksnkndksdjksdjbdbwdbwqidbwqibdiwbdibwidbqwidbqwidbwqidbiqwbdiqwbdiqwbdiqwbdiqbwdibqwdibqwidbwdibqwidbiqdbiqdbiqbdiqbdiqiwdbwqdwidwbqidbwqidiqw","Nust"));
        answersCardList.add(new AnswersCard(R.drawable.default_avatar,"Ramish9333293732dinsdioncdsoicnsdocnsocnosdcnsoncosdncosdnocnsdocnsodcnsdoncosdncosncosncodncods","Uet"));
        answersCardList.add(new AnswersCard(R.drawable.default_avatar,"Ramish","Fast"));
        answersCardList.add(new AnswersCard(R.drawable.default_avatar,"Ramissdbskcbscbsdbcksbcskbcscbkscbkscbksckscnsckh","Nust"));
        
    }

}
